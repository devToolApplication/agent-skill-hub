---
name: finalize-koc-candidates
description: "Phase 3 only: independently re-check Phase 2-completed KOC candidates using MongoDB trace plus fresh Facebook MCP evidence, persist any new evidence through MongoDB MCP, audit Phase 2 gate-by-gate, commit final accepted/manual_check/rejected state, then export eligible rows and verify the configured Excel/Google Sheet."
---

# Finalize KOC Candidates — Phase 3 + Export

## Ownership

Chỉ final review + export. Review đúng một candidate mỗi context. Không discover candidate mới, nhưng được search/read Facebook để tìm evidence mới cho candidate đang final-review.

Đọc trước: `references/db-schema.md`, `references/contracts.md`, `references/criteria.md`, `references/phase3-review.schema.json`.

## Required capabilities

- Facebook MCP cho public profile/post/comment/history checks.
- MongoDB MCP cho trace/state/locks/reviews.
- Google Sheets/Excel capability khi campaign có export destination.


## Required Facebook MCP Tool Map

Use these exact Facebook MCP tools. Do not leave tool choice implicit.

- `facebook_gql_search_people`: discover candidate profiles/people by campaign keywords, exact name, role, school/parent/teacher terms.
- `facebook_gql_search_posts`: discover public posts by campaign keywords, education/parenting/teacher terms, app/promo history terms, and exact-name queries.
- `facebook_gql_user_posts`: enter/read one candidate's personal profile feed by profile URL, username, or author ID.
- `facebook_gql_post_comments`: read comments/comment tree for a specific post URL used as evidence.
- `facebook_gql_search_groups`: discover relevant public groups only when the search strategy requires group sources.
- `facebook_gql_group_posts`: read posts from a specific group URL when a lead/evidence source comes from a group.

MongoDB persistence must use the available MongoDB MCP/database capability, not Facebook MCP. Facebook MCP is only for Facebook read/search actions.
## Candidate selection + anti-anchoring

Normal scope: Phase 2 completed, Phase 3 not_started/failed.

**Stage A — independent, chưa xem Phase 2 conclusion**
1. Preselect chỉ `candidate_id` bằng DB query; không fetch Phase 2 decision/review content.
2. Acquire Phase 3 lock.
3. Load identity/canonical state/posts/comments/evidence nhưng exclude `phase2.decision`, `phase2.review_id`, Phase 2 review.
4. D?ng `facebook_gql_user_posts` m? l?i profile/feed; d?ng `facebook_gql_post_comments` re-read comments; d?ng `facebook_gql_search_posts` cho exact-name/history/app-promo checks; d?ng `facebook_gql_group_posts` n?u evidence t? group; t?m evidence m?i n?u c?n.
5. Upsert canonical candidate/post/comment state + insert append-only `koc_evidence` bằng MongoDB MCP.
6. Chỉ dùng evidence đã commit DB để tính `independent_gates` + gate details.
7. Freeze independent result (`independent_trace.frozen_at`, exact evidence IDs).

Nếu runtime hỗ trợ sub-agent, ưu tiên sub-agent Stage A chỉ nhận evidence, không nhận Phase 2 conclusion.

**Stage B — audit Phase 2**
8. Chỉ sau freeze mới query candidate Phase 2 pointer và load active Phase 2 review.
9. So từng gate, explanation, evidence source, confidence, missing evidence.
10. Ghi `comparison.agrees_with_phase2` và disagreements chi tiết: gate, Phase 2 value, Phase 3 value, why, evidence IDs.

## Live evidence rule

Phase 3 có thể tìm thấy post/comment/fact mà Phase 2 bỏ sót. Khi đó:
- upsert `koc_posts`/`koc_comments`/`profile_state` hiện tại bằng MongoDB MCP;
- insert evidence mới vào `koc_evidence`;
- giữ nguyên evidence cũ để audit;
- review phải trỏ exact evidence ID mới nếu dùng nó để đảo/confirm kết luận.

## Final decision

```text
accepted = mọi normal gate pass + hard gate pass
manual_check = không fail + có >=1 blocked + hard gate pass
rejected = còn lại
```

Export eligibility mặc định:
- accepted → true;
- manual_check → true chỉ khi promo gate pass (và campaign không có exclusion khác chặt hơn);
- rejected → false.

Phase 3 phải sinh authoritative fields cho export: `final_confidence`, `exclusion_risks`, `missing_evidence`, `tool_limitations`, `checks_completed`.

## Commit protocol

1. Validate Phase 3 schema + `scripts/validate_phase3.py` nếu runtime cho phép.
2. Insert immutable Phase 3 review.
3. Conditional update candidate bằng đúng lock token: phase3 pointer/decision/completed, final_status, export.eligible, clear lock.
4. Failure không xóa evidence/reviews cũ.

## Export

Chỉ sau khi tất cả candidate trong scope `phase3.status=completed`.

Query `export.eligible=true`, dedupe canonical identity, xuất đúng 10 cột contract. Destination lấy từ `campaign.config.export_destination`; không đoán khi ambiguous.

Ghi → read-back verify 10 columns, row count, không có rejected/formula error → insert `koc_exports` → update candidate `export.status=exported`. Nếu export fail, giữ nguyên Phase 3 final state và ghi `export_failed`/audit error.

Chat báo counts + link/destination + verify result; DB vẫn là authoritative trace.
