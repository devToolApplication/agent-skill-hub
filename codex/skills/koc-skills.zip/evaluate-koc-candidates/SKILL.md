---
name: evaluate-koc-candidates
description: "Phase 2 only: load Phase 1 KOC state from MongoDB, re-check each candidate deeply with Facebook MCP, persist any new profile/post/comment evidence through MongoDB MCP, evaluate every gate with concrete evidence IDs and explanations, and save immutable versioned Phase 2 reviews. Never discover unrelated candidates or export."
---

# Evaluate KOC Candidates — Phase 2

## Ownership

Chỉ Phase 2. Review **đúng một candidate mỗi review context**. Không discover candidate mới, nhưng được search/read Facebook để tìm evidence mới cho candidate hiện tại.

Đọc trước: `references/db-schema.md`, `references/contracts.md`, `references/criteria.md`, `references/phase2-review.schema.json`.

## Required capabilities

- Facebook MCP để mở/read public profile/post/comment/search history.
- MongoDB MCP để query/upsert/insert/atomic conditional update.

Không dùng custom scraper, browser automation, HTTP script, regex/text-mining script hay batch prompt để judge candidate.


## Required Facebook MCP Tool Map

Use these exact Facebook MCP tools. Do not leave tool choice implicit.

- `facebook_gql_search_people`: discover candidate profiles/people by campaign keywords, exact name, role, school/parent/teacher terms.
- `facebook_gql_search_posts`: discover public posts by campaign keywords, education/parenting/teacher terms, app/promo history terms, and exact-name queries.
- `facebook_gql_user_posts`: enter/read one candidate's personal profile feed by profile URL, username, or author ID.
- `facebook_gql_post_comments`: read comments/comment tree for a specific post URL used as evidence.
- `facebook_gql_search_groups`: discover relevant public groups only when the search strategy requires group sources.
- `facebook_gql_group_posts`: read posts from a specific group URL when a lead/evidence source comes from a group.

MongoDB persistence must use the available MongoDB MCP/database capability, not Facebook MCP. Facebook MCP is only for Facebook read/search actions.
## Candidate selection + lock

Normal scope:

```text
campaign_id = requested
phase1.status = completed
phase2.status in [not_started, failed]
```

Acquire lock bằng compare-and-set theo `references/contracts.md`; set `lock_token` + lease. Không acquire được thì skip. Re-review explicit tạo review version mới, không overwrite.

## DB is starting trace, Facebook is live verification

Phase 2 **không được chỉ đọc DB rồi chốt**. Với từng candidate:

1. Load canonical candidate + existing posts/comments/evidence từ MongoDB.
2. D?ng `facebook_gql_user_posts` m? l?i ??ng profile/feed v? verify identity.
3. Ki?m tra k? recent feed v? strongest education posts b?ng `facebook_gql_user_posts`; ??c comments b?ng `facebook_gql_post_comments`; ki?m tra l?ch s?/app promo b?ng `facebook_gql_search_posts` v?i exact-name/profile identifiers; n?u evidence t? group th? d?ng `facebook_gql_group_posts`.
4. Nếu tìm thấy post/comment/profile fact mới hoặc metrics thay đổi: **upsert canonical state bằng MongoDB MCP**.
5. Với mỗi fact dùng cho review: **insert `koc_evidence` append-only bằng MongoDB MCP trước khi dùng trong gate**.
6. Nếu live evidence mâu thuẫn evidence cũ, giữ evidence cũ và insert evidence mới; gate explanation phải nêu conflict và vì sao source mới/verified có trọng lượng.

## Minimum live checks

Mỗi candidate cố gắng kiểm tra:
- profile identity;
- gender theo config;
- role + grade;
- ít nhất strongest education post + verified engagement;
- recent activity và đủ recent non-share posts theo config;
- 2–3 representative comments khi accessible;
- bounded prior-English-app history khi exclusion bật;
- sales/share/seeding/hard-reject patterns.

Tool/access block phải được trace bằng `koc_evidence.evidence_type=tool_limitation` nếu nó ảnh hưởng gate.

## Gate evidence detail

Mỗi `gate_details.<gate>` bắt buộc có:
- `result`;
- `evidence_used[]` với exact `evidence_id`, source ID/URL, `observation` cụ thể, `relevance` cụ thể;
- `why`: giải thích criteria + evidence;
- `missing_or_blocked`;
- `checks_used[]` nêu check nào đã làm, kết quả và evidence IDs.

Không dùng evidence chưa commit DB. Không dùng generic explanation.

## Gates

Theo thứ tự:
`identity`, `gender`, `role_grade`, `relevant_education_post`, `qualifying_engagement`, `recent_activity`, `deep_review_coverage`, `comment_quality`, `no_prior_english_app_promo`, `no_hard_reject`.

## Deterministic status

```text
Pass = mọi normal gate pass + no_hard_reject pass
Need manual check = không fail + có >=1 blocked + no_hard_reject pass
Reject = còn lại
```

Confidence không override matrix.

## Commit protocol

1. Acquire lock.
2. Load DB state/evidence.
3. Facebook MCP deep check.
4. MongoDB MCP upsert canonical candidate/post/comment state.
5. MongoDB MCP insert mọi new evidence trace.
6. Build review, bảo đảm mọi `evidence_used.evidence_id` tồn tại DB.
7. Validate JSON schema + chạy `scripts/validate_phase2.py` nếu runtime cho phép; script chỉ validate structure/invariant, không judge Facebook.
8. Insert immutable `koc_reviews` (`type=phase2`) trước.
9. Conditional update candidate bằng đúng `lock_token`: review pointer, decision, completed, clear lock.
10. Failure: set failed/last_error khi sở hữu lock; không xóa evidence/review cũ.

## Completion

Campaign Phase 2 chỉ completed khi mọi candidate trong scope có durable active Phase 2 review. Chat output chỉ counts/gate statistics; authoritative data ở MongoDB.
