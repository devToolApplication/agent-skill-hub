// mongosh one-time admin setup for KOC pipeline v4.
// Normal skill runs use MongoDB MCP, not this script, for reads/writes.

const status = ["not_started","in_progress","completed","failed"];
const nullableString = {bsonType:["string","null"]};
const nullableDate = {bsonType:["date","null"]};

const schemas = {
 campaigns: {$jsonSchema:{bsonType:"object",required:["schema_version","campaign_id","name","criteria_version","config","workflow","counts","created_at","updated_at"],properties:{
  schema_version:{enum:["4.0"]},campaign_id:{bsonType:"string"},name:{bsonType:"string"},criteria_version:{bsonType:"string"},
  config:{bsonType:"object",required:["target_roles","required_gender","student_grade_min","student_grade_max","target_count","qualifying_engagement_min_exclusive","recent_activity_days","relevant_post_max_age_days","minimum_recent_nonshare_posts_for_pass","desired_recent_nonshare_posts","exclude_prior_english_app_promoters","search_budget","export_destination"],properties:{
   target_roles:{bsonType:"array"},required_gender:{enum:["female","male","any"]},student_grade_min:{bsonType:"int",minimum:1},student_grade_max:{bsonType:"int",minimum:1},target_count:{bsonType:"int",minimum:1},qualifying_engagement_min_exclusive:{bsonType:"int",minimum:0},recent_activity_days:{bsonType:"int",minimum:1},relevant_post_max_age_days:{bsonType:"int",minimum:1},minimum_recent_nonshare_posts_for_pass:{bsonType:"int",minimum:1},desired_recent_nonshare_posts:{bsonType:"int",minimum:1},exclude_prior_english_app_promoters:{bsonType:"bool"},
   search_budget:{bsonType:"object",required:["max_queries_per_bucket","raw_pool_goal"],properties:{max_queries_per_bucket:{bsonType:"int",minimum:1},raw_pool_goal:{bsonType:"int",minimum:1}}},
   export_destination:{bsonType:"object",required:["type","file_id","file_name","folder_hint","worksheet","range"]}
  }},workflow:{bsonType:"object",required:["phase1_status","phase2_status","phase3_status","export_status"]},counts:{bsonType:"object"},created_at:{bsonType:"string"},updated_at:{bsonType:"string"}
 }}},
 candidates: {$jsonSchema:{bsonType:"object",required:["schema_version","campaign_id","candidate_id","platform","identity","profile_state","phase1","phase2","phase3","final_status","export","created_at","updated_at"],properties:{
  schema_version:{enum:["4.0"]},campaign_id:{bsonType:"string"},candidate_id:{bsonType:"string"},platform:{enum:["facebook"]},
  identity:{bsonType:"object",required:["name","profile_url","canonical_profile_url","author_id","username"]},
  profile_state:{bsonType:"object",required:["bio_summary","role_hint","personal_profile_signal","last_verified_phase","last_verified_at"],properties:{role_hint:{enum:["parent","teacher","unclear"]},personal_profile_signal:{enum:["strong","mixed","weak","unknown"]}}},
  phase1:{bsonType:"object",required:["status","run_id","recent_post_keys","evaluation_post_keys","english_app_check_post_keys","evidence_ids","checks_attempted","tool_limitations","completed_at"],properties:{status:{enum:status},recent_post_keys:{bsonType:"array"},evaluation_post_keys:{bsonType:"array"},english_app_check_post_keys:{bsonType:"array"},evidence_ids:{bsonType:"array"}}},
  phase2:{bsonType:"object",required:["status","review_id","decision","lock_token","lock_acquired_at","lock_expires_at","completed_at","last_error"],properties:{status:{enum:status},decision:{enum:["Pass","Need manual check","Reject",null]}}},
  phase3:{bsonType:"object",required:["status","review_id","decision","lock_token","lock_acquired_at","lock_expires_at","completed_at","last_error"],properties:{status:{enum:status},decision:{enum:["accepted","manual_check","rejected",null]}}},
  final_status:{enum:["not_finalized","accepted","manual_check","rejected"]},export:{bsonType:"object",required:["eligible","status","export_id","exported_at"],properties:{eligible:{bsonType:"bool"},status:{enum:["not_exported","exported","export_failed"]}}},created_at:{bsonType:"string"},updated_at:{bsonType:"string"}
 }}},
 posts: {$jsonSchema:{bsonType:"object",required:["schema_version","campaign_id","candidate_id","post_key","post_id","url","date","purpose","is_candidate_attributable","is_share","topic","text_summary","metrics","commercial_signals","first_seen_phase","last_verified_phase","first_seen_at","updated_at"],properties:{schema_version:{enum:["4.0"]},campaign_id:{bsonType:"string"},candidate_id:{bsonType:"string"},post_key:{bsonType:"string"},purpose:{bsonType:"array"},is_candidate_attributable:{bsonType:"bool"},is_share:{bsonType:"bool"},metrics:{bsonType:"object",required:["reactions","comments","shares","verified","verified_at"]},commercial_signals:{bsonType:"object",required:["commercial_cta","english_app_promo","app_or_platform","promo_type"]},first_seen_phase:{enum:[1,2,3]},last_verified_phase:{enum:[1,2,3]},first_seen_at:{bsonType:"string"},updated_at:{bsonType:"string"}}}},
 comments: {$jsonSchema:{bsonType:"object",required:["schema_version","campaign_id","candidate_id","post_key","comment_key","comment_id","source_url","author_public_name","text_summary","quality_signal","first_seen_phase","last_verified_phase","first_seen_at","updated_at"],properties:{schema_version:{enum:["4.0"]},campaign_id:{bsonType:"string"},candidate_id:{bsonType:"string"},post_key:{bsonType:"string"},comment_key:{bsonType:"string"},text_summary:{bsonType:"string"},quality_signal:{enum:["natural","promotional","unclear"]},first_seen_phase:{enum:[1,2,3]},last_verified_phase:{enum:[1,2,3]},first_seen_at:{bsonType:"string"},updated_at:{bsonType:"string"}}}},
 evidence: {$jsonSchema:{bsonType:"object",required:["schema_version","evidence_id","campaign_id","candidate_id","phase","run_id","evidence_type","claim_type","claim","observation","source","facebook_check","structured_value","supports_gates","evidence_strength","created_at"],properties:{schema_version:{enum:["4.0"]},evidence_id:{bsonType:"string"},campaign_id:{bsonType:"string"},candidate_id:{bsonType:"string"},phase:{enum:[1,2,3]},run_id:{bsonType:"string"},evidence_type:{enum:["profile_claim","post_snapshot","comment_snapshot","metric_snapshot","history_check","tool_limitation"]},claim_type:{enum:["identity","gender","role","grade","education_relevance","recent_activity","engagement","comment_quality","english_app_promo","commercial_pattern","hard_reject","other"]},claim:{bsonType:"string"},observation:{bsonType:"string"},source:{bsonType:"object",required:["source_type","source_id","source_url","parent_source_id"]},facebook_check:{bsonType:"object",required:["tool_name","checked_at","query_or_action"]},structured_value:{bsonType:"object"},supports_gates:{bsonType:"array"},evidence_strength:{enum:["direct","supporting","weak"]},created_at:{bsonType:"string"}}}},
 reviews: {$jsonSchema:{bsonType:"object",required:["schema_version","criteria_version","type","phase","review_id","campaign_id","candidate_id","review_version","run_id","created_at"],properties:{schema_version:{enum:["4.0"]},criteria_version:{bsonType:"string"},type:{enum:["phase2","phase3"]},phase:{enum:[2,3]},review_id:{bsonType:"string"},campaign_id:{bsonType:"string"},candidate_id:{bsonType:"string"},review_version:{bsonType:"int",minimum:1},run_id:{bsonType:"string"},created_at:{bsonType:"string"}},oneOf:[{properties:{type:{enum:["phase2"]},phase:{enum:[2]}},required:["input_trace","gates","gate_details","live_facebook_check","reviewed_evidence","final_status","confidence","reason","missing_evidence","exclusion_risks","tool_limitations"]},{properties:{type:{enum:["phase3"]},phase:{enum:[3]}},required:["phase2_review_id","independent_trace","live_facebook_check","independent_gates","gate_details","comparison","final_status","export_eligible","final_confidence","final_reason","exclusion_risks","missing_evidence","tool_limitations","checks_completed"]}]}},
 exports: {$jsonSchema:{bsonType:"object",required:["schema_version","export_id","campaign_id","destination","candidate_ids","row_count","column_count","verified","errors","created_at"],properties:{schema_version:{enum:["4.0"]},export_id:{bsonType:"string"},campaign_id:{bsonType:"string"},destination:{bsonType:"object"},candidate_ids:{bsonType:"array"},row_count:{bsonType:"int",minimum:0},column_count:{bsonType:"int",minimum:0},verified:{bsonType:"bool"},errors:{bsonType:"array"},created_at:{bsonType:"string"}}}}
};

function ensureCollection(name, validator) {
 const exists=db.getCollectionNames().includes(name);
 if(!exists) db.createCollection(name,{validator,validationLevel:"strict",validationAction:"error"});
 else db.runCommand({collMod:name,validator,validationLevel:"strict",validationAction:"error"});
}
for (const [name,v] of Object.entries({koc_campaigns:schemas.campaigns,koc_candidates:schemas.candidates,koc_posts:schemas.posts,koc_comments:schemas.comments,koc_evidence:schemas.evidence,koc_reviews:schemas.reviews,koc_exports:schemas.exports})) ensureCollection(name,v);

db.koc_campaigns.createIndex({campaign_id:1},{unique:true});
db.koc_candidates.createIndex({campaign_id:1,candidate_id:1},{unique:true});
db.koc_candidates.createIndex({campaign_id:1,"phase1.status":1,"phase2.status":1,"phase3.status":1});
db.koc_candidates.createIndex({campaign_id:1,final_status:1,"export.eligible":1});
db.koc_posts.createIndex({campaign_id:1,candidate_id:1,post_key:1},{unique:true});
db.koc_comments.createIndex({campaign_id:1,candidate_id:1,post_key:1,comment_key:1},{unique:true});
db.koc_evidence.createIndex({evidence_id:1},{unique:true});
db.koc_evidence.createIndex({campaign_id:1,candidate_id:1,phase:1,claim_type:1,created_at:-1});
db.koc_reviews.createIndex({review_id:1},{unique:true});
db.koc_reviews.createIndex({campaign_id:1,candidate_id:1,type:1,review_version:1},{unique:true});
db.koc_exports.createIndex({export_id:1},{unique:true});
print("KOC pipeline v4 MongoDB schema/indexes initialized.");
