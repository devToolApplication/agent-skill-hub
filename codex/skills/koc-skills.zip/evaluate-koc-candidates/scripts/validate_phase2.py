#!/usr/bin/env python3
import json,sys
from pathlib import Path

def fail(m): print("INVALID:",m,file=sys.stderr); raise SystemExit(1)

NORMAL = ["identity","gender","role_grade","relevant_education_post","qualifying_engagement","recent_activity","deep_review_coverage","comment_quality","no_prior_english_app_promo"]
ALL = NORMAL + ["no_hard_reject"]

def check_gate_details(data, matrix_key):
    gates=data[matrix_key]
    details=data["gate_details"]
    if set(gates)!=set(ALL): fail("gate matrix phải có đúng 10 gate")
    if set(details)!=set(ALL): fail("gate_details phải có đúng 10 gate")
    for g in ALL:
        if details[g]["result"] != gates[g]: fail(f"gate_details.{g}.result != {matrix_key}.{g}")
        for ev in details[g]["evidence_used"]:
            if not ev.get("evidence_id"): fail(f"{g}: evidence_used thiếu evidence_id")
            if not ev.get("observation") or not ev.get("relevance"): fail(f"{g}: evidence phải có observation + relevance")

def deterministic(gates):
    vals=[gates[g] for g in NORMAL]
    hard=gates["no_hard_reject"]
    if hard=="pass" and all(v=="pass" for v in vals): return "Pass"
    if hard=="pass" and "fail" not in vals and "blocked" in vals: return "Need manual check"
    return "Reject"


def main():
    if len(sys.argv)!=2: fail("usage: validate_phase2.py review.json")
    d=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    check_gate_details(d,"gates")
    if d["gates"]["no_hard_reject"] not in {"pass","fail"}: fail("no_hard_reject chỉ pass|fail")
    expected=deterministic(d["gates"])
    if d["final_status"]!=expected: fail(f"final_status phải là {expected}")
    live=set(d["input_trace"]["live_evidence_ids"])
    declared=set(d["live_facebook_check"]["new_evidence_ids"])
    if live != declared: fail("input_trace.live_evidence_ids phải khớp live_facebook_check.new_evidence_ids")
    print("VALID")
if __name__=="__main__": main()
