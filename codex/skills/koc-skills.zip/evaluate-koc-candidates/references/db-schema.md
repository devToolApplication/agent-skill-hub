# MongoDB schema — KOC pipeline v4

MongoDB là **nguồn trace/audit và workflow state** giữa các phase. Facebook MCP vẫn là nguồn đọc Facebook công khai ở cả Phase 1, 2 và 3.

## Quy tắc bất biến

1. Không truyền candidate/evidence giữa phase chỉ bằng chat hoặc memory.
2. `koc_candidates`, `koc_posts`, `koc_comments` là canonical/latest state và được phép upsert khi Phase 2/3 xác minh dữ liệu mới.
3. `koc_evidence` là append-only. Không update/xóa evidence cũ chỉ vì có evidence mới.
4. Mọi evidence dùng trong `gate_details` phải có `evidence_id` tồn tại trong `koc_evidence` cùng `campaign_id` + `candidate_id`.
5. Phase 2/3 chỉ được dùng live Facebook evidence sau khi evidence đó đã được MongoDB MCP commit thành công.
6. `koc_reviews` là immutable theo version. Re-run tạo `review_version` mới.
7. Mọi document chính có `schema_version="4.0"`; campaign có `criteria_version` để phát hiện mismatch giữa skill và DB.

## 1. `koc_campaigns`

```json
{
  "schema_version": "4.0",
  "campaign_id": "campaign:...",
  "name": "string",
  "criteria_version": "koc-criteria-v4",
  "config": {
    "target_roles": ["parent", "teacher"],
    "required_gender": "female|male|any",
    "student_grade_min": 1,
    "student_grade_max": 9,
    "target_count": 10,
    "qualifying_engagement_min_exclusive": 80,
    "recent_activity_days": 90,
    "relevant_post_max_age_days": 365,
    "minimum_recent_nonshare_posts_for_pass": 5,
    "desired_recent_nonshare_posts": 10,
    "exclude_prior_english_app_promoters": true,
    "search_budget": {
      "max_queries_per_bucket": 4,
      "raw_pool_goal": 30
    },
    "export_destination": {
      "type": "google_sheet|excel|null",
      "file_id": "string|null",
      "file_name": "string|null",
      "folder_hint": "string|null",
      "worksheet": "string|null",
      "range": "string|null"
    }
  },
  "workflow": {
    "phase1_status": "not_started|in_progress|completed|failed",
    "phase2_status": "not_started|in_progress|completed|failed",
    "phase3_status": "not_started|in_progress|completed|failed",
    "export_status": "not_started|in_progress|completed|failed"
  },
  "counts": {
    "discovered": 0,
    "phase1_completed": 0,
    "phase2_completed": 0,
    "phase3_completed": 0,
    "accepted": 0,
    "manual_check": 0,
    "rejected": 0,
    "exported": 0
  },
  "created_at": "ISODate",
  "updated_at": "ISODate"
}
```

## 2. `koc_candidates`

Canonical candidate state. Không nhét toàn bộ post/comment vào đây.

```json
{
  "schema_version": "4.0",
  "campaign_id": "string",
  "candidate_id": "fb:<author_id>|profile:<stable-key>",
  "platform": "facebook",
  "identity": {
    "name": "string",
    "profile_url": "string|null",
    "canonical_profile_url": "string|null",
    "author_id": "string|null",
    "username": "string|null"
  },
  "profile_state": {
    "bio_summary": "string|null",
    "role_hint": "parent|teacher|unclear",
    "personal_profile_signal": "strong|mixed|weak|unknown",
    "last_verified_phase": 1,
    "last_verified_at": "ISODate|null"
  },
  "phase1": {
    "status": "not_started|in_progress|completed|failed",
    "run_id": "string|null",
    "recent_post_keys": ["string"],
    "evaluation_post_keys": ["string"],
    "english_app_check_post_keys": ["string"],
    "evidence_ids": ["string"],
    "checks_attempted": ["string"],
    "tool_limitations": ["string"],
    "completed_at": "ISODate|null"
  },
  "phase2": {
    "status": "not_started|in_progress|completed|failed",
    "review_id": "string|null",
    "decision": "Pass|Need manual check|Reject|null",
    "lock_token": "string|null",
    "lock_acquired_at": "ISODate|null",
    "lock_expires_at": "ISODate|null",
    "completed_at": "ISODate|null",
    "last_error": "string|null"
  },
  "phase3": {
    "status": "not_started|in_progress|completed|failed",
    "review_id": "string|null",
    "decision": "accepted|manual_check|rejected|null",
    "lock_token": "string|null",
    "lock_acquired_at": "ISODate|null",
    "lock_expires_at": "ISODate|null",
    "completed_at": "ISODate|null",
    "last_error": "string|null"
  },
  "final_status": "not_finalized|accepted|manual_check|rejected",
  "export": {
    "eligible": false,
    "status": "not_exported|exported|export_failed",
    "export_id": "string|null",
    "exported_at": "ISODate|null"
  },
  "created_at": "ISODate",
  "updated_at": "ISODate"
}
```

Unique: `(campaign_id, candidate_id)`.

## 3. `koc_posts`

Canonical/latest state của một post. Phase 2/3 được upsert khi thấy post mới hoặc giá trị mới.

`post_key` bắt buộc và ổn định:
- `id:<post_id>` khi có post ID;
- `url:<canonical_public_url>` khi không có post ID.

```json
{
  "schema_version": "4.0",
  "campaign_id": "string",
  "candidate_id": "string",
  "post_key": "id:...|url:...",
  "post_id": "string|null",
  "url": "string|null",
  "date": "YYYY-MM-DD|null",
  "purpose": ["discovery", "recent_activity", "evaluation", "english_app_check", "commercial_check"],
  "is_candidate_attributable": true,
  "is_share": false,
  "topic": "string|null",
  "text_summary": "string|null",
  "metrics": {
    "reactions": 0,
    "comments": 0,
    "shares": 0,
    "verified": true,
    "verified_at": "ISODate|null"
  },
  "commercial_signals": {
    "commercial_cta": false,
    "english_app_promo": false,
    "app_or_platform": "string|null",
    "promo_type": "intro|review|affiliate|discount|trial|testimonial|campaign|unclear|null"
  },
  "first_seen_phase": 1,
  "last_verified_phase": 2,
  "first_seen_at": "ISODate",
  "updated_at": "ISODate"
}
```

Unique: `(campaign_id, candidate_id, post_key)`.

## 4. `koc_comments`

Canonical/latest state của comment đã dùng hoặc đã kiểm tra.

```json
{
  "schema_version": "4.0",
  "campaign_id": "string",
  "candidate_id": "string",
  "post_key": "string",
  "comment_key": "id:...|url:...|synthetic:...",
  "comment_id": "string|null",
  "source_url": "string|null",
  "author_public_name": "string|null",
  "text_summary": "string",
  "quality_signal": "natural|promotional|unclear",
  "first_seen_phase": 1,
  "last_verified_phase": 3,
  "first_seen_at": "ISODate",
  "updated_at": "ISODate"
}
```

Unique: `(campaign_id, candidate_id, post_key, comment_key)`.

## 5. `koc_evidence` — append-only audit log

Đây là collection quan trọng nhất để trace. Một evidence record phải nêu **bằng chứng cụ thể**, không chỉ ghi “đã check profile”.

```json
{
  "schema_version": "4.0",
  "evidence_id": "ev:<campaign>:<candidate>:<unique>",
  "campaign_id": "string",
  "candidate_id": "string",
  "phase": 1,
  "run_id": "string",
  "evidence_type": "profile_claim|post_snapshot|comment_snapshot|metric_snapshot|history_check|tool_limitation",
  "claim_type": "identity|gender|role|grade|education_relevance|recent_activity|engagement|comment_quality|english_app_promo|commercial_pattern|hard_reject|other",
  "claim": "Ứng viên tự xưng là mẹ của học sinh lớp 4",
  "observation": "Bài post ... có câu/tóm tắt cụ thể ...; source thuộc đúng profile ...",
  "source": {
    "source_type": "profile|post|comment|search",
    "source_id": "string|null",
    "source_url": "string|null",
    "parent_source_id": "string|null"
  },
  "facebook_check": {
    "tool_name": "string",
    "checked_at": "ISODate",
    "query_or_action": "string|null"
  },
  "structured_value": {
    "reactions": 96,
    "comments": 18,
    "grade": 4,
    "app_or_platform": null
  },
  "supports_gates": ["role_grade"],
  "evidence_strength": "direct|supporting|weak",
  "created_at": "ISODate"
}
```

Quy tắc:
- append-only; không update record cũ;
- `claim` + `observation` phải cụ thể đủ để người audit hiểu vì sao source có ý nghĩa;
- không chép dài nguyên văn nội dung Facebook; dùng tóm tắt ngắn và giữ URL/ID;
- evidence mới mâu thuẫn evidence cũ => insert record mới, không sửa record cũ;
- tool bị chặn => insert `evidence_type=tool_limitation` khi limitation ảnh hưởng gate.

Unique: `evidence_id`.

## 6. `koc_reviews`

Phase 2/3 review immutable theo version. Review phải trỏ tới exact evidence IDs.

### Phase 2

```json
{
  "schema_version": "4.0",
  "criteria_version": "koc-criteria-v4",
  "type": "phase2",
  "phase": 2,
  "review_id": "p2:<campaign>:<candidate>:v1",
  "campaign_id": "string",
  "candidate_id": "string",
  "review_version": 1,
  "run_id": "string",
  "input_trace": {
    "db_loaded_at": "ISODate",
    "candidate_updated_at": "ISODate",
    "existing_evidence_ids": ["string"],
    "live_evidence_ids": ["string"],
    "post_keys_reviewed": ["string"],
    "comment_keys_reviewed": ["string"]
  },
  "gates": {"identity":"pass", "gender":"pass", "role_grade":"pass", "relevant_education_post":"pass", "qualifying_engagement":"pass", "recent_activity":"pass", "deep_review_coverage":"pass", "comment_quality":"pass", "no_prior_english_app_promo":"pass", "no_hard_reject":"pass"},
  "gate_details": {
    "identity": {
      "result": "pass",
      "evidence_used": [{"evidence_id":"ev:...","source_type":"profile","source_id":"...","source_url":"...","observation":"Cụ thể evidence chứng minh gì","relevance":"Vì sao evidence này đáp ứng gate"}],
      "why": "Kết luận chi tiết theo criteria",
      "missing_or_blocked": [],
      "checks_used": [{"check":"profile identity","result":"matched","evidence_ids":["ev:..."],"limitation":null}]
    }
  },
  "live_facebook_check": {
    "attempted": true,
    "matched_candidate": true,
    "sources_checked": ["url/id"],
    "new_evidence_ids": ["ev:..."],
    "updated_post_keys": ["id:..."],
    "updated_comment_keys": ["id:..."],
    "checked_at": "ISODate",
    "limitations": []
  },
  "reviewed_evidence": {"recent_posts_count":5,"comments_count":3,"education_posts_count":1,"engagement_verified":true},
  "final_status": "Pass|Need manual check|Reject",
  "confidence": "high|medium|low",
  "reason": ["1-3 lý do"],
  "missing_evidence": [],
  "exclusion_risks": [],
  "tool_limitations": [],
  "created_at": "ISODate"
}
```

### Phase 3

Giống nguyên tắc Phase 2 nhưng có `independent_gates`, `comparison`, `final_confidence`, `checks_completed`, và `phase2_review_id`.

Required unique indexes:

```js
db.koc_reviews.createIndex({review_id:1}, {unique:true});
db.koc_reviews.createIndex({campaign_id:1,candidate_id:1,type:1,review_version:1}, {unique:true});
```

## 7. `koc_exports`

Lưu destination, candidate IDs, row/column count, verify result và errors. Chỉ insert audit export sau khi ghi + read-back verify.

## Commit order bắt buộc

### Evidence update trong Phase 1/2/3
1. Facebook MCP đọc source.
2. MongoDB MCP upsert canonical `koc_candidates`/`koc_posts`/`koc_comments` nếu state mới hơn hoặc mới phát hiện.
3. MongoDB MCP insert `koc_evidence` append-only.
4. Chỉ sau khi bước 2-3 thành công mới được dùng evidence đó trong gate/review.

### Phase 2/3 review
1. acquire lock bằng compare-and-set;
2. collect/check Facebook + commit evidence;
3. build review + validate deterministic invariants;
4. insert immutable review;
5. update active review pointer + status bằng lock token hiện tại;
6. clear lock fields.

Không rollback/xóa evidence cũ khi bước sau fail.
