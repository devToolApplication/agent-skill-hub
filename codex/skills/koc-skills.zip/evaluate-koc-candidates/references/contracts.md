# Contracts giữa 3 skill — v4

## Handoff model

- Facebook MCP: đọc dữ liệu Facebook công khai ở cả 3 phase.
- MongoDB MCP: handoff/state/trace giữa phase và nơi persist mọi evidence/review.
- Chat/memory không phải handoff.

## Skill 1 → DB

Skill 1 tìm lead và thu evidence ban đầu. Candidate sẵn sàng cho Phase 2 khi `phase1.status=completed` và mọi `phase1.evidence_ids`/post keys tham chiếu tồn tại trong DB.

Skill 1 **không** tạo Pass/Reject.

## DB + Facebook → Skill 2

Phase 2 bắt đầu bằng candidate Phase 1 đã completed. Với từng candidate:

1. đọc canonical DB state + evidence cũ;
2. mở đúng profile bằng Facebook MCP;
3. kiểm tra sâu hơn profile/recent posts/evaluation posts/comments/history;
4. evidence mới hoặc thay đổi phải upsert canonical state và insert `koc_evidence` bằng MongoDB MCP;
5. chỉ evidence đã commit DB mới được ghi vào `gate_details.evidence_used`;
6. chốt review versioned rồi update `candidate.phase2`.

Phase 2 không search candidate mới, nhưng **được search Facebook để tìm evidence mới cho candidate đang review**.

## DB + Facebook → Skill 3

Phase 3 chỉ nhận candidate có Phase 2 completed. Để giảm anchoring:

1. preselect candidate ID bằng query chỉ trả `candidate_id`;
2. load candidate/evidence nhưng không load `phase2.decision`, `phase2.review_id` hay Phase 2 review trong independent stage;
3. Facebook MCP kiểm tra lại và có thể tìm evidence mới;
4. persist evidence mới bằng MongoDB MCP;
5. tính/freeze `independent_gates`;
6. sau đó mới query `phase2.review_id` và load Phase 2 review để compare.

Nếu runtime hỗ trợ sub-agent, ưu tiên một sub-agent độc lập chỉ nhận evidence packet, không nhận Phase 2 conclusion.

## Evidence trace contract

Mỗi evidence dùng trong review phải có:

- `evidence_id` tồn tại trong `koc_evidence`;
- `source_type`, `source_id`, `source_url` nếu có;
- `observation`: mô tả cụ thể source cho thấy gì;
- `relevance`: vì sao source có ý nghĩa với gate;
- phase/run/timestamp trong evidence record.

Không dùng claim kiểu “profile phù hợp” hoặc “comments tự nhiên” mà không nêu source cụ thể và quan sát cụ thể.

## Lock contract

Phase 2/3 phải acquire lock bằng conditional atomic update:

```text
match campaign_id + candidate_id
AND phaseX.status in [not_started, failed] (hoặc explicit re-review)
AND (lock_expires_at null hoặc đã hết hạn)
→ set status=in_progress, lock_token, lock_acquired_at, lock_expires_at
```

Mọi update hoàn tất phải match đúng `lock_token`. Không acquire được lock thì skip candidate; không ghi đè agent khác.

## Review version contract

Unique `(campaign_id,candidate_id,type,review_version)`. Khi re-review: lấy max version hiện có rồi tạo version tiếp theo; nếu duplicate key do race, reload version và retry sau khi lock hợp lệ.

## Status mapping

Phase 2:
- `Pass`: mọi normal gate pass và `no_hard_reject=pass`.
- `Need manual check`: không fail, có >=1 blocked, hard reject pass.
- `Reject`: còn lại.

Phase 3:
- `accepted`: matrix tương đương Pass.
- `manual_check`: matrix tương đương Need manual check.
- `rejected`: còn lại.

`required_gender=any` => gender gate được coi `pass` với explanation “campaign không giới hạn gender”.
`exclude_prior_english_app_promoters=false` => gate promo được coi `pass` với explanation “campaign không bật exclusion này”; vẫn có thể lưu evidence promo để trace.

## Excel / Google Sheet contract

Chỉ export sau khi mọi candidate trong finalization scope có `phase3.status=completed`.

Đúng 10 cột:

1. `#`
2. `Tên - Link profile`
3. `Vai trò`
4. `Bằng chứng chính - có link`
5. `Tương tác`
6. `Kết luận cuối`
7. `Độ tin cậy`
8. `Rủi ro`
9. `Đã tự kiểm`
10. `Cần kiểm tiếp`

Mapping authoritative từ Phase 3:
- Kết luận cuối → `final_status`
- Độ tin cậy → `final_confidence`
- Rủi ro → `exclusion_risks`
- Đã tự kiểm → `checks_completed`
- Cần kiểm tiếp → `missing_evidence + tool_limitations`

Sau ghi phải read-back verify 10 columns, row count, không có `rejected`, không có formula error; sau đó insert `koc_exports` và update candidate export state.
