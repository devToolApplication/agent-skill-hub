---
name: search-koc-discovery
description: "Phase 1 only: discover plausible Vietnamese Facebook KOC candidates, read public profile/post/comment evidence with Facebook MCP, and persist canonical state plus append-only evidence trace with MongoDB MCP. Never make Pass/Reject decisions or export."
---

# Search KOC Discovery — Phase 1

## Ownership

Chỉ discovery + evidence collection. Không đánh giá Pass/Reject và không export.

Đọc trước: `references/db-schema.md`, `references/contracts.md`, `references/search-strategy.md`, các JSON schema liên quan.

## Required capabilities

- Facebook MCP: search/read public profile, post, metrics, comments.
- MongoDB MCP: find/query, insert, upsert/update, atomic conditional update.

## Required Facebook MCP Tool Map

Use these exact Facebook MCP tools. Do not leave tool choice implicit.

- `facebook_gql_search_people`: discover candidate profiles/people by campaign keywords, exact name, role, school/parent/teacher terms.
- `facebook_gql_search_posts`: discover public posts by campaign keywords, education/parenting/teacher terms, app/promo history terms, and exact-name queries.
- `facebook_gql_user_posts`: enter/read one candidate's personal profile feed by profile URL, username, or author ID.
- `facebook_gql_post_comments`: read comments/comment tree for a specific post URL used as evidence.
- `facebook_gql_search_groups`: discover relevant public groups only when the search strategy requires group sources.
- `facebook_gql_group_posts`: read posts from a specific group URL when a lead/evidence source comes from a group.

MongoDB persistence must use the available MongoDB MCP/database capability, not Facebook MCP. Facebook MCP is only for Facebook read/search actions.

Không viết scraper/script/browser automation để lấy Facebook. Script trong `scripts/` chỉ dùng setup/validation DB, không dùng để scrape hay judge candidate.

## Source/state rule

Facebook MCP là nguồn đọc Facebook. MongoDB là handoff/trace. Mọi candidate/evidence muốn Phase 2 dùng phải được commit DB.

## Candidate discovery

1. Load `koc_campaigns[campaign_id]`; kiểm tra `schema_version=4.0` và `criteria_version=koc-criteria-v4`.
2. Set campaign Phase 1 in progress.
3. Search theo bounded buckets t? `search-strategy.md` v? `config.search_budget`: d?ng `facebook_gql_search_people` cho profile/people leads, `facebook_gql_search_posts` cho public post leads, `facebook_gql_search_groups` khi c?n t?m group source, v? `facebook_gql_group_posts` khi c?n ??c post trong group c? th?.
4. Dedupe theo author ID → canonical profile URL → exact username → normalized name chỉ khi có identity evidence bổ sung.
5. V?i t?ng lead plausible: d?ng `facebook_gql_user_posts` ?? ??c ??ng profile/feed; d?ng `facebook_gql_post_comments` ?? ??c comments c?a post evidence; d?ng `facebook_gql_group_posts` n?u evidence n?m trong group.
6. Kh?ng d?ng search snippet l?m evidence cu?i n?u source g?c ??c ???c b?ng `facebook_gql_user_posts`, `facebook_gql_group_posts`, ho?c `facebook_gql_post_comments`.

## Persist evidence — bắt buộc

Mỗi fact quan trọng phải được MongoDB MCP persist ngay:

- upsert candidate canonical/profile state;
- upsert `koc_posts` cho post quan trọng;
- upsert `koc_comments` cho comments được dùng/kiểm tra;
- insert append-only `koc_evidence` với `claim` + `observation` cụ thể + source URL/ID + Facebook tool/check + gate liên quan.

Ví dụ evidence tốt:
- claim: `Role signal: parent`;
- observation: `Post id 123 trên đúng profile nói về “con đang học lớp 4”; profile và post cùng author_id ...`;
- source URL/ID;
- supports_gates: `["role_grade"]`.

Không ghi evidence chung chung như `profile phù hợp`.

## Phase 1 candidate state

Khi bắt đầu candidate:

```text
phase1.status=in_progress
phase2.status=not_started
phase3.status=not_started
final_status=not_finalized
export.status=not_exported
```

Phase 1 lưu các `recent_post_keys`, `evaluation_post_keys`, `english_app_check_post_keys`, `evidence_ids`, checks và limitations.

Chỉ set `phase1.status=completed` sau khi mọi referenced post/evidence đã tồn tại DB và identity đã được kiểm tra đủ để biết candidate plausible. Phase 1 không tạo gate status.

## History check

Nếu campaign bật exclusion app tiếng Anh, Phase 1 thực hiện bounded initial history check. Kết quả chỉ lưu factual evidence (`english_app_promo` signal/history check); quyết định fail/pass thuộc Phase 2/3.

## Resume/idempotency

Query DB trước khi tìm. Upsert canonical state theo unique keys; không duplicate candidate/post/comment. `koc_evidence` không overwrite. Resume không được tự xóa/đổi Phase 2/3 review đã completed.

## Completion

Verify bằng MongoDB MCP:
- candidate ready đều `phase1.status=completed`;
- mọi post key/evidence ID referenced tồn tại đúng campaign/candidate;
- counts campaign khớp DB.

Chat chỉ trả operational summary Phase 1, không shortlist Pass/Reject.
