# Search strategy — Phase 1 only

Phase 1 chỉ discovery + evidence collection, không Pass/Reject.

## Query buckets

A. Parent achievement/certificate
- `"mẹ tự hào" con "lớp 4"`
- `"con gái" Starters`
- `"con trai" Movers Cambridge`

B. Parent learning journey
- `"học tiếng Anh" con "lớp 3"`
- `"đồng hành cùng con" học tiếng Anh`
- `"tiến bộ" con tiếng Anh`

C. Parenting/school sharing
- `"phụ huynh" "lớp 5" học tiếng Anh`
- `"mẹ chia sẻ" con học`

D. Teacher classroom/student progress
- `"giáo viên chủ nhiệm" "lớp 6" học sinh`
- `"học sinh tiến bộ" giáo viên`
- `"chúc mừng học sinh" "đạt giải"`

E. Teacher personal profile
- `"giáo viên" "lớp 4" chia sẻ học sinh`
- `"cô giáo" học sinh tiếng Anh`

## Budget

Dùng `campaign.config.search_budget`:
- `max_queries_per_bucket` là trần query/bucket;
- `raw_pool_goal` là số unique plausible candidates mục tiêu của Phase 1.

Dừng bucket sớm nếu kết quả chủ yếu duplicate hoặc rõ ràng không phải profile cá nhân. Không dùng từ `Reject`/`Pass` ở Phase 1.

## Lead prefilter

Thu name, profile URL/author ID, source post URL, role/grade/topic hint, visible engagement, page/business signal. Search snippet chỉ để discovery; profile/post evidence phải đọc lại qua Facebook MCP khi có thể.

## Evidence collection fallback

Cho một candidate đã plausible:
1. profile/recent feed;
2. strongest relevant post + metrics;
3. representative comments;
4. history search về app tiếng Anh;
5. exact-name + stable identifier search cho recent/education evidence;
6. ghi mọi source/check/limitation vào MongoDB.

Phase 1 chỉ ghi factual evidence như `english_app_promo=true/false/unclear`, không tự tạo gate status hay final decision.

## Diversity

Trước khi kết thúc raw pool, kiểm tra pool có bị tập trung duy nhất vào một query bucket không. Nếu còn budget, bổ sung ít nhất một bucket khác để giảm discovery bias.
